clc
clear all

%%%%%%%%%%%%%%%%%%%%%%%%%%
c1=load('a.txt');
t1=c1(:,1);
l1=c1(:,2);
m=c1(:,4);

figure(1)
plot(t1,m,t1,l1)
pbaspect([1 1 1])

%%%%%%%%%%%%%%%%%%%%%%%%%%
c1=load('b.txt');
t1=c1(:,1);
l1=c1(:,2);
m=c1(:,4);

figure(2)
plot(t1,m,t1,l1)
pbaspect([1 1 1])


%%%%%%%%%%%%%%%%%%%%%%%%%%%
c1=load('c.txt');
t1=c1(:,1);
l1=c1(:,2);
m=c1(:,4);

figure(3)
plot(t1,m,t1,l1)
pbaspect([1 1 1])











