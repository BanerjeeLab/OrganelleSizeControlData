clear all
clc

l=load('L.txt');
t=l(:,1);
l1=l(:,2);
l2=l(:,3);

lx=load('L_cut.txt');
tc=lx(:,1);
lc=lx(:,2);

ly=load('L_intact.txt');
ti=ly(:,1);
li=ly(:,2);

figure(1)
plot(t,l1, t,l2)
hold on
plot(tc+992,lc)
hold on
plot(ti+992,li)
hold off


