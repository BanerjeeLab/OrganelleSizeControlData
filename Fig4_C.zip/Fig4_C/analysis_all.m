clc
clear all

nn=4500;

rr=[4 5 6 7 8 9 10 15 20 25 30 35 40 45 50];

nc_nevd=[];
nc_nvvd=[];
nc_nvsd=[];

rmax = 8		%% Renormalizing factor - max nucleus radius (in um) for the data set

%%%%%%%%%%%%%%%%% NE-VD %%%%%%%%%%%%%%%%%%%%

nc=[];

for i=1:numel(rr)
vc(i)=log(rr(i));
end


n=load('data/nr_4.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(1) log(vn)];


n=load('data/nr_5.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(2) log(vn)];


n=load('data/nr_6.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(3) log(vn)];


n=load('data/nr_7.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(4) log(vn)];


n=load('data/nr_8.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(5) log(vn)];


n=load('data/nr_9.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(6) log(vn)];


n=load('data/nr_10.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(7) log(vn)];


n=load('data/nr_15.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(8) log(vn)];


n=load('data/nr_20.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(9) log(vn)];


n=load('data/nr_25.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(10) log(vn)];


n=load('data/nr_30.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(11) log(vn)];



n=load('data/nr_35.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(12) log(vn)];



n=load('data/nr_40.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(13) log(vn)];



n=load('data/nr_45.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(14) log(vn)];



n=load('data/nr_50.txt');
mrn=mean(n(nn:end,2));
vn=mrn/rmax;				%(4/3)*pi*mrn^3;

nc = [nc; vc(15) log(vn)];

nc_nevd=nc;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


vx=load('logR_logRn.txt');

figure(1)
plot(vx(:,1),vx(:,2),'ko-', nc_nevd(:,1),nc_nevd(:,2))


%%plot(nc_nevd(:,1),nc_nevd(:,2),nc_nvvd(:,1),nc_nvvd(:,2),nc_nvsd(:,1),nc_nvsd(:,2), vx(:,1),vx(:,2),'ko-')












