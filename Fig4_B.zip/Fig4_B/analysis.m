clc
clear all

l=load('l.txt');
n=load('n.txt');

t=l(:,1);
l1=l(:,2);

ne=n(:,2);
nr=sqrt(ne);

nn=4500;

l1=l1./mean(l1(nn:end));
ne=ne./mean(ne(nn:end));
nr=nr./mean(nr(nn:end));

figure(1)
plot(t,ne,'k', t,nr,'blue', t,l1,'red')