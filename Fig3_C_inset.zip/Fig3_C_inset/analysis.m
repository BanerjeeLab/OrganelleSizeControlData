clear all
clc


l1=load('l_2200.txt');
l2=load('l_4400.txt');
l3=load('l_6200.txt');
l4=load('l_8600.txt');
l5=load('l_12700.txt');
l6=load('l_22000.txt');

exp=load('V_cell_cento.txt');

Nexp=exp(:,1);
lexp=exp(:,2);
erexp=exp(:,3);


N=[2200; 4400; 6200; 8600; 12700; 22000];
l=[mean(l1(:,2)); mean(l2(:,2)); mean(l3(:,2)); mean(l4(:,2)); mean(l5(:,2)); mean(l6(:,2))];
ler=[std(l1(:,2)); std(l2(:,2)); std(l3(:,2)); std(l4(:,2)); std(l5(:,2)); std(l6(:,2))];


 errorbar(Nexp,lexp,erexp)
  hold on
 errorbar(N,l,ler)
