clc
clear all

nn=450;

np = [1,3,5,10,20,30];

n=load('1/nr.txt');

t1=n(:,1);
nr1=n(:,2);
nnn=mean(nr1(nn:end));			%% renormalizing factor
nr1=nr1./mean(nr1(nn:end));
rmn1=nnn;


n=load('3/nr.txt');

t2=n(:,1);
nr2=n(:,2);
rmn2=mean(nr2(nn:end));
nr2=nr2./nnn;



n=load('5/nr.txt');

t3=n(:,1);
nr3=n(:,2);
rmn3=mean(nr3(nn:end));
nr3=nr3./nnn;



n=load('10/nr.txt');

t4=n(:,1);
nr4=n(:,2);
rmn4=mean(nr4(nn:end));
nr4=nr4./nnn;



n=load('20/nr.txt');

t5=n(:,1);
nr5=n(:,2);
rmn5=mean(nr5(nn:end));
nr5=nr5./nnn;



n=load('30/nr.txt');

t6=n(:,1);
nr6=n(:,2);
rmn6=mean(nr6(nn:end));
nr6=nr6./nnn;




figure(1)
plot(t1,nr1, t2,nr2, t3,nr3, t4,nr4, t5,nr5, t6,nr6)





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



diaexp=load('exp/np_Rn.txt');
dia=diaexp(:,2);
exnp=diaexp(:,1);

npx=exnp./50;
d=dia./max(dia);


rm = [rmn1,rmn2,rmn3,rmn4,rmn5,rmn6];
rm=rm./max(rm);


figure(2)
plot(npx,d, np,rm)



































