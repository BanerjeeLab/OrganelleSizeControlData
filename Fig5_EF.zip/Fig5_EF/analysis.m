clc
clear all

%%%%%%%%%%%%%%%%%%%%%%%%%%
c1=load('b.txt');
t1=c1(:,1);
l1=c1(:,2);
l2=c1(:,3);

figure(2)
plot(t1,l1,t1,l2)
pbaspect([1 1 1])


%%%%%%%%%%%%%%%%%%%%%%%%%%%
c1=load('c.txt');
t1=c1(:,1);
l1=c1(:,2);
l2=c1(:,3);

figure(3)
plot(t1,l1,t1,l2)
pbaspect([1 1 1])











