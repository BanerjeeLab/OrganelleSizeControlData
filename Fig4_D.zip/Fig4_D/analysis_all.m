clc
clear all

nn=4500;

rr=[4 5 6 7 8 9 10];

nc_nevd=[];
nc_nvvd=[];
nc_nvsd=[];


%%%%%%%%%%%%%%%%% NE-VD %%%%%%%%%%%%%%%%%%%%

nc=[];

for i=1:numel(rr)
vc(i)=(4/3)*pi*rr(i)^3;
end

n=load('NEVD/nr_4.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(1) vn];


n=load('NEVD/nr_5.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(2) vn];


n=load('NEVD/nr_6.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(3) vn];


n=load('NEVD/nr_7.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(4) vn];


n=load('NEVD/nr_8.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(5) vn];


n=load('NEVD/nr_9.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(6) vn];



n=load('NEVD/nr_10.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(7) vn];

nc_nevd=nc;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%% NV-VD %%%%%%%%%%%%%%%%%%%%

nc=[];

for i=1:numel(rr)
vc(i)=(4/3)*pi*rr(i)^3;
end

n=load('NVVD/nr_4.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(1) vn];


n=load('NVVD/nr_5.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(2) vn];


n=load('NVVD/nr_6.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(3) vn];


n=load('NVVD/nr_7.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(4) vn];


n=load('NVVD/nr_8.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(5) vn];


n=load('NVVD/nr_9.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(6) vn];



n=load('NVVD/nr_10.txt');
mrn=mean(n(nn:end,2));
vn=(4/3)*pi*mrn^3;

nc = [nc; vc(7) vn];

nc_nvvd=nc;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


vx=load('vcvn.txt');

figure(1)
loglog(nc_nevd(:,1),nc_nevd(:,2),nc_nvvd(:,1),nc_nvvd(:,2), vx(:,1),vx(:,2),'ko-')















