clc
clear all

%%%%%%%%%%%%%%%%%%%%%%%%%%
c1=load('ab0/l.txt');
t1=c1(:,1);
l1=c1(:,2);
l2=c1(:,3);


c2=load('ab0/t_xyz.txt');
t2=c2(:,1);
p1=c2(:,2);
p2=c2(:,3);


figure(1)
plot(t1,l1,t1,l2, t2,p1, t2,p2)
pbaspect([1 1 1])

%%%%%%%%%%%%%%%%%%%%%%%%%%
c1=load('ab1/l.txt');
t1=c1(:,1);
l1=c1(:,2);
l2=c1(:,3);


c2=load('ab1/t_xyz.txt');
t2=c2(:,1);
p1=c2(:,2);
p2=c2(:,3);


figure(2)
plot(t1,l1,t1,l2, t2,p1, t2,p2)
pbaspect([1 1 1])


%%%%%%%%%%%%%%%%%%%%%%%%%%%
c1=load('abm1/l.txt');
t1=c1(:,1);
l1=c1(:,2);
l2=c1(:,3);


c2=load('abm1/t_xyz.txt');
t2=c2(:,1);
p1=c2(:,2);
p2=c2(:,3);

figure(3)
plot(t1,l1,t1,l2)
hold on
plot(t2,p1,'LineWidth',10)
hold on
plot(t2,p2,'LineWidth',4)
hold off
pbaspect([1 1 1])











