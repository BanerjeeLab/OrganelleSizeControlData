clear all;
clc

er = 1e-4;
small = 0.01;

flag_stable=0;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

t_end = 1000000;		% total time

%%--- initialization ---
y10 = 12;		% length
y20 = 0;		% myosin

%28.422237 0.000001

%%%%%%%%%%%%% call ODE solver %%%%%%%%%%%%%%

options=odeset('RelTol',1e-10,'AbsTol',1e-10);

[T,Y] = ode15s(@dydt,[0 t_end],[y10 y20],options);				%% 


%------- solution done -------------

n1 = Y(:,1);		% length
n2 = Y(:,2);		% myosin

%%%%%%%% write data %%%%%%%%%%%%%%%%%%%%%%%%

fid10=fopen('../data/t_xyz.txt','w');

for kk=1:numel(T)
 fprintf(fid10, '%f %f %f\n', T(kk),Y(kk,1),Y(kk,2));
end

%%%%%%% plot all quantities %%%%%%%%%%%%%%%

  h = figure('vis', 'off');
  set(gcf,'PaperUnits','inches','PaperPosition',[0 0 12 8])

  plot(T,Y(:,1),'r-','LineWidth',4)  
  hold on
  plot(T,Y(:,2),'k--','LineWidth',4)
  hold off

  legend({'n_1(t)','n_2(t)'})		%'Location','southwest'

  xt = get(gca, 'XTick');
  set(gca, 'FontSize', 16)
  yt = get(gca, 'YTick');
  set(gca, 'FontSize', 16)

  print(h,'-dpng','-r250',['../graph/n1n2', '.png'])




close all;
















