clear all
clc


l1=load('l_1.txt');
l2=load('l_2.txt');
l4=load('l_4.txt');
l6=load('l_6.txt');
l8=load('l_8.txt');
l9=load('l_9.txt');
l12=load('l_12.txt');
l16=load('l_16.txt');

d=0.5;

N=[1; 2; 4; 6; 8; 9; 12; 16];

p1=[1];
mean1=mean(l1(8000:end,2));
std1=std(l1(8000:end,2));

p2=[2-d/2; 2+d/2];
l=l2(8000:end,2:3);
mean2=mean(l);
std2=std(l);


l=l4(8000:end,2:5);
mean4=mean(l);
std4=std(l);

l=l6(8000:end,2:7);
mean6=mean(l);
std6=std(l);


l=l8(8000:end,2:9);
mean8=mean(l);
std8=std(l);


l=l9(8000:end,2:10);
mean9=mean(l);
std9=std(l);


l=l12(8000:end,2:13);
mean12=mean(l);
std12=std(l);


l=l16(8000:end,2:17);
mean16=mean(l);
std16=std(l);

ltot=[sum(mean1); sum(mean2); sum(mean4); sum(mean6); sum(mean8); sum(mean9); sum(mean12); sum(mean16)];


lmean=[mean(mean1); mean(mean2); mean(mean4); mean(mean6); mean(mean8); mean(mean9); mean(mean12); mean(mean16)];


%%%%------------- exp1 --------------------
mexp1=[];
exp1=[];

l4e1=load('exp1/4.txt');
l6e1=load('exp1/6.txt');
l8e1=load('exp1/8.txt');
l9e1=load('exp1/9.txt');
l12e1=load('exp1/12.txt');

n=numel(l4e1);
for i=1:n
exp1=[exp1; 4+0.2*(2*rand()-1),l4e1(i)];
end

mexp1=[mexp1; 4,mean(l4e1)/4,std(l4e1)];

n=numel(l6e1);
for i=1:n
exp1=[exp1; 6+0.2*(2*rand()-1),l6e1(i)];
end

mexp1=[mexp1; 6,mean(l6e1)/6,std(l6e1)];


n=numel(l8e1);
for i=1:n
exp1=[exp1; 8+0.2*(2*rand()-1),l8e1(i)];
end

mexp1=[mexp1; 8,mean(l8e1)/8,std(l8e1)];


n=numel(l9e1);
for i=1:n
exp1=[exp1; 9+0.2*(2*rand()-1),l9e1(i)];
end

mexp1=[mexp1; 9,mean(l9e1)/9,std(l9e1)];


n=numel(l12e1);
for i=1:n
exp1=[exp1; 12+0.2*(2*rand()-1),l12e1(i)];
end

mexp1=[mexp1; 12,mean(l12e1)/12,std(l12e1)];

%%%%------------------------------------------



%%%%------------- exp2 --------------------

mexp2=[];

exp2=[];

l1e2=load('exp2/1.txt');
l2e2=load('exp2/2.txt');
l4e2=load('exp2/4.txt');


n=numel(l1e2);
for i=1:n
exp2=[exp2; 1+0.2*(2*rand()-1),l1e2(i)];
end

mexp2=[mexp2; 1,mean(l1e2),std(l1e2)];


n=numel(l2e2);
for i=1:n
exp2=[exp2; 2+0.2*(2*rand()-1),l2e2(i)];
end

mexp2=[mexp2; 2,mean(l2e2)/2,std(l2e2)];


n=numel(l4e2);
for i=1:n
exp2=[exp2; 4+0.2*(2*rand()-1),l4e2(i)];
end

mexp2=[mexp2; 4,mean(l4e2)/4,std(l4e2)];


%%%%------------------------------------------


figure(1)
scatter(exp1(:,1),exp1(:,2),200,'d')
hold on
scatter(exp2(:,1),exp2(:,2),200,'s')
hold on
plot(N,ltot,'ro-','MarkerSize',10)
hold off






figure(2)
nt=500;

l=l1(1:nt,:);
plot(l(:,1),l(:,2))
hold on

l=l2(1:nt,:);
plot(l(:,1),l(:,2))
hold on

l=l4(1:nt,:);
plot(l(:,1),l(:,2))
hold on

l=l8(1:nt,:);
plot(l(:,1),l(:,2))
hold on

l=l16(1:nt,:);
plot(l(:,1),l(:,2))
hold off


figure(3)
errorbar(mexp1(:,1),mexp1(:,2),mexp1(:,3),'kd','MarkerSize',10)
hold on
errorbar(mexp2(:,1),mexp2(:,2),mexp2(:,3),'bs','MarkerSize',10)
hold on
errorbar(1,mean1,std1,'ro','MarkerSize',10)
hold on
errorbar(2*ones(2,1),mean2,std2,'ro','MarkerSize',10)
hold on
errorbar(4*ones(4,1),mean4,std4,'ro','MarkerSize',10)
hold on
errorbar(8*ones(8,1),mean8,std8,'ro','MarkerSize',10)
hold on
errorbar(16*ones(16,1),mean16,std16,'ro','MarkerSize',10)
hold off






figure(4)
errorbar(mexp1(:,1),mexp1(:,2),mexp1(:,3),'kd','MarkerSize',10)
hold on
errorbar(mexp2(:,1),mexp2(:,2),mexp2(:,3),'bs','MarkerSize',10)
hold on
plot(N,lmean)
hold off


























